// Château Grand: extracts the exact mobile geometry defined by src/architecture.js.
// Run: node tools/export-mobile-glb.cjs
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const root=path.resolve(__dirname,'..');
const win={};
let triangles=0,degenerate=0;
const P=[],N=[],K=[];
const STWHITE=[.96,.91,.83],TRIM=[.85,.79,.68],SLATE=[.20,.27,.36],SLATEDARK=[.17,.23,.31],GOLD=[.76,.55,.26],GLASS=[.24,.32,.36],FLOORLIGHT=[.84,.82,.76];
function tri(a,b,c,col,mat=0){
 const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
 let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
 let length=Math.hypot(nx,ny,nz);
 if(length<1e-12){degenerate++;length=1;}
 nx/=length;ny/=length;nz/=length;
 for(const p of [a,b,c]){P.push(...p);N.push(nx,ny,nz);K.push(...col);}
 triangles++;
}
function quad(a,b,c,d,col,mat=0){tri(a,b,c,col,mat);tri(a,c,d,col,mat);}
function box(x,y,z,w,h,d,col,mat=0){
 const x0=x-w/2,x1=x+w/2,y0=y-h/2,y1=y+h/2,z0=z-d/2,z1=z+d/2;
 quad([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],col,mat);
 quad([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],col,mat);
 quad([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],col,mat);
 quad([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],col,mat);
 quad([x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],col,mat);
 quad([x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],col,mat);
}
function cylinder(x,y,z,rb,rt,height,col,mat=0,segments=16){
 let lo=y-height/2,hi=y+height/2;
 for(let j=0;j<segments;j++){
   let a=j*Math.PI*2/segments,b=(j+1)*Math.PI*2/segments;
   let p1=[x+Math.cos(a)*rb,lo,z+Math.sin(a)*rb],p2=[x+Math.cos(b)*rb,lo,z+Math.sin(b)*rb],p3=[x+Math.cos(b)*rt,hi,z+Math.sin(b)*rt],p4=[x+Math.cos(a)*rt,hi,z+Math.sin(a)*rt];
   quad(p1,p2,p3,p4,col,mat);tri([x,hi,z],p4,p3,col,mat);tri([x,lo,z],p2,p1,col,mat);
 }
}
function sphere(x,y,z,r,col,mat=0,rings=6,seg=10){
 for(let i=0;i<rings;i++){
   const a=Math.PI*(i/rings-.5),b=Math.PI*((i+1)/rings-.5);
   for(let j=0;j<seg;j++){
     const aa=j*2*Math.PI/seg,bb=(j+1)*2*Math.PI/seg;
     const p=(phi,th)=>[x+r*Math.cos(phi)*Math.cos(th),y+r*Math.sin(phi),z+r*Math.cos(phi)*Math.sin(th)];
     quad(p(a,aa),p(a,bb),p(b,bb),p(b,aa),col,mat);
   }
 }
}
function roof(x,z,w,d,bot,top,inset,col=SLATE){
 const x0=x-w/2,x1=x+w/2,z0=z-d/2,z1=z+d/2,xx0=x0+inset,xx1=x1-inset,zz0=z0+inset,zz1=z1-inset;
 quad([x0,bot,z1],[x1,bot,z1],[xx1,top,zz1],[xx0,top,zz1],col,1);
 quad([x1,bot,z0],[x0,bot,z0],[xx0,top,zz0],[xx1,top,zz0],col,1);
 quad([x1,bot,z1],[x1,bot,z0],[xx1,top,zz0],[xx1,top,zz1],col,1);
 quad([x0,bot,z0],[x0,bot,z1],[xx0,top,zz1],[xx0,top,zz0],col,1);
 box(x,top,z,w-2*inset,.22,d-2*inset,SLATEDARK,1);
}
const input=fs.readFileSync(path.join(root,'src','architecture.js'),'utf8');
vm.runInNewContext(input,{window:win,URLSearchParams,location:{search:'?quality=mobile'},Math,Float32Array,console},{filename:'architecture.js',timeout:20000});
const model=win.createChateauGeometry({MOBILE:true,box,cylinder,sphere,quad,tri,roof,GLASS,TRIM,GOLD,STWHITE,SLATE,FLOORLIGHT});
const seams=model.ROOF_JUNCTIONS;
if(!Array.isArray(seams)||seams.length!==8)throw new Error('Expected eight new real roof valleys, got '+(seams||[]).length);
for(const seam of seams){
 const [x0,y0,z0]=seam.start,[x1,y1,z1]=seam.end;
 const rise=y1-y0;
 if(Math.abs(y0-16.9)>1e-9 || Math.abs(Math.abs(x1-x0)*seam.slopeWing-rise)>1e-8 || Math.abs(Math.abs(z1-z0)*seam.slopeCross-rise)>1e-8)throw new Error('Roof valley leaves slope planes '+JSON.stringify(seam));
 if(!(rise>0 && rise<5.0))throw new Error('Bad roof join height');
}
const n=P.length/3;
if(n!==3*triangles || N.length!==P.length || K.length!==P.length)throw new Error('Mismatched vertex attributes');
for(let i=0;i<P.length;i++)if(!Number.isFinite(P[i])||!Number.isFinite(N[i])||!Number.isFinite(K[i]))throw new Error('Nonfinite geometry at '+i);
const mins=[Infinity,Infinity,Infinity],maxs=[-Infinity,-Infinity,-Infinity];
for(let i=0;i<P.length;i+=3)for(let j=0;j<3;j++){mins[j]=Math.min(mins[j],P[i+j]);maxs[j]=Math.max(maxs[j],P[i+j]);}
const typed=[new Float32Array(P),new Float32Array(N),new Float32Array(K)];
const buffers=typed.map(arr=>Buffer.from(arr.buffer));
const bin=Buffer.concat(buffers);
const gltf={
 asset:{version:'2.0',generator:'Chateau Grand V5.10 exact mobile geometry exporter'},
 scene:0,scenes:[{nodes:[0]}],nodes:[{name:'Chateau Grand V5.10',mesh:0}],
 meshes:[{name:'Chateau Grand V5.10 mobile geometry',primitives:[{attributes:{POSITION:0,NORMAL:1,COLOR_0:2},material:0,mode:4}]}],
 materials:[{name:'Model vertex colors; live PBR textures in game',pbrMetallicRoughness:{baseColorFactor:[1,1,1,1],metallicFactor:0,roughnessFactor:.84},doubleSided:true}],
 buffers:[{byteLength:bin.length}],
 bufferViews:buffers.map((b,i)=>({buffer:0,byteOffset:buffers.slice(0,i).reduce((n,b)=>n+b.length,0),byteLength:b.length,target:34962})),
 accessors:[
  {bufferView:0,byteOffset:0,componentType:5126,count:n,type:'VEC3',min:mins,max:maxs},
  {bufferView:1,byteOffset:0,componentType:5126,count:n,type:'VEC3'},
  {bufferView:2,byteOffset:0,componentType:5126,count:n,type:'VEC3'}
 ]
};
let json=Buffer.from(JSON.stringify(gltf));
json=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,0x20)]);
const file=Buffer.alloc(12+8+json.length+8+bin.length);
file.write('glTF',0);file.writeUInt32LE(2,4);file.writeUInt32LE(file.length,8);
file.writeUInt32LE(json.length,12);file.write('JSON',16);json.copy(file,20);
const off=20+json.length;file.writeUInt32LE(bin.length,off);file.write('BIN\0',off+4);bin.copy(file,off+8);
const dest=path.join(root,'models','Chateau-Grand-V5.10-Geometrie.glb');
fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,file);
const diagnostics={version:'5.10',triangles,vertices:n,degenerate,room_zones:model.ROOMS.length,roof_junctions:seams.map(s=>({wing:s.wing,range:s.range,start:s.start,end:s.end})),bbox:{min:mins,max:maxs},export:dest};
fs.writeFileSync(path.join(root,'docs','DACHANSCHLUESSE-V5.10.json'),JSON.stringify(diagnostics,null,2)+'\n');
console.log(JSON.stringify({triangles,vertices:n,degenerate,seams:seams.length,rooms:model.ROOMS.length,fileBytes:file.length},null,2));
