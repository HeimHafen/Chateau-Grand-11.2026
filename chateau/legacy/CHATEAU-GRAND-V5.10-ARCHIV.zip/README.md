# CHÂTEAU GRAND V5.10 — DACHANSCHLÜSSE

**Projektstand: Schritt 3 · ausschließlich die Dachanschlüsse**

Die Fassade und die Seitenflügel bleiben auf dem Stand V5.9; die Kuppel und ihre Basis werden bewusst **nicht** umgestaltet. In dieser Version wurde nur die Geometrie an den Übergängen Hauptdach ↔ Seitenflügel ↔ rückwärtiger Quertrakt korrigiert.

## Was neu ist

- **Acht berechnete Dachkehlen**: Die obere Begrenzung der Verbindungsstreifen wird aus den beiden tatsächlichen Mansardneigungen ermittelt; kein frei stehendes diagonales Balkenwerk mehr.
- **Zwei Seitenflügel-Dächer verlängert**: Ihre vorderen und hinteren Endkappen liegen nun innerhalb der angrenzenden quer laufenden Dachkörper und erscheinen nicht mehr als frei stehende Dachkeile.
- **Sichtbare Gesimse nur an freien Seitenkanten**: Die eingebetteten Flügelenden haben keine künstlich hervorstehenden Quergesimse mehr.
- **Durchgehende Verbindung auf Traufhöhe**: Schmale Verbindungsstreifen überdecken die 2 Fugen an jedem Seitenflügel.
- Bestehende Frontfassade, Kuppel, Fenster, Graswelt, fünf Etagen und Steuerung blieben erhalten.

## Installation in Working Copy / GitHub Pages

1. ZIP entpacken, **nicht das ZIP selbst** in das Repository legen.
2. Die Dateien `index.html`, `src/`, `assets/`, `models/`, `docs/` direkt in das **Hauptverzeichnis** von `Chateau-Grand-2027` übertragen. Bestehende gleichnamige Dateien ersetzen.
3. Der alte `models/Chateau-Grand-V5.8-Frontfassade.glb` kann entfernt werden, da das aktuelle Modell jetzt V5.10 heißt.
4. Commit → Push. Kein Force Push.
5. Die veröffentlichte GitHub-Pages-Spieladresse mit `?v=510` öffnen. Oben rechts muss `GRAND CHÂTEAU · V5.10` stehen.

## Projektdateien

- `src/architecture.js`: **aktive Spielgeometrie** mit berechneten Dachanschlüssen
- `src/app.js`: WebGL-Renderer, Steuerung, Etagen
- `assets/materials/`: vorhandene Texturen
- `models/Chateau-Grand-V5.10-Geometrie.glb`: **neu aus dieser V5.10-Geometrie** generierter eigenständiger kompletter Modellstand in der mobilen Detailstufe, einschließlich Gelände
- `tools/export-mobile-glb.cjs`: reproduzierbarer Exporter für das aktuelle Geometriemodell; unter Node.js ausführen
- `docs/DACHANSCHLUESSE-V5.10.json`: Verlauf aller acht Dachkehlen und Modellstatistiken

**Teststatus:** JavaScript-Syntax geprüft, acht Dachkehlen rechnerisch validiert, der GLB-Export erfolgreich mit Trimesh wieder eingelesen. Der mobile Modellstand umfasst 151.139 Dreiecke. Das beweist **keine** fotorealistische Architektur, keine garantierte kollisionsfreie/ wasserdichte Netzgeometrie und ist **kein iPhone-Safari-Grafiktest**.

**Lizenzhinweis:** Die bisherigen Bildmaterialien stammen aus der früher bereitgestellten Projektdatei. Nutzungsrechte vor kommerzieller Veröffentlichung prüfen.
